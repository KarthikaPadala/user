package com.student.users.dto;
import lombok.Data;
@Data
public class AddressRequestDto {
    private String addressLine1;
    private String addressLine2;
    private String city;
}
